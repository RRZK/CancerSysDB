barcodes<-read.delim("query1.csv",stringsAsFactors=F)[,1]
bc_pos<-read.delim("query2.csv",stringsAsFactors=F)[,1]
bc_neg<-setdiff(barcodes,bc_pos)
vartypedata<-read.delim("query3.csv",stringsAsFactors=F,sep=",",header=F)

patients<-unique(vartypedata[,1])

AC<-AG<-AT<-CG<-CT<-GT<-numeric(0)
for(i in 1:length(patients)){
      this_vartypes<-vartypedata[vartypedata[,1]==patients[i],]
      AC[i]<-sum(this_vartypes[,6]=="A" & this_vartypes[,7]=="C")+sum(this_vartypes[,6]=="T" & this_vartypes[,7]=="G")
      AG[i]<-sum(this_vartypes[,6]=="A" & this_vartypes[,7]=="G")+sum(this_vartypes[,6]=="T" & this_vartypes[,7]=="C")
      AT[i]<-sum(this_vartypes[,6]=="A" & this_vartypes[,7]=="T")+sum(this_vartypes[,6]=="T" & this_vartypes[,7]=="A")
      CG[i]<-sum(this_vartypes[,6]=="C" & this_vartypes[,7]=="G")+sum(this_vartypes[,6]=="G" & this_vartypes[,7]=="C")
      CT[i]<-sum(this_vartypes[,6]=="C" & this_vartypes[,7]=="T")+sum(this_vartypes[,6]=="G" & this_vartypes[,7]=="A")
      GT[i]<-sum(this_vartypes[,6]=="G" & this_vartypes[,7]=="T")+sum(this_vartypes[,6]=="C" & this_vartypes[,7]=="A")
}
	
freq<-rbind(AC,AG,AT,CG,CT,GT)
colnames(freq)<-patients
freq_norm<-freq
for(i in 1:ncol(freq)){freq_norm[,i]<-round(100*freq[,i]/sum(freq[,i]),1)}

#freq_norm<-freq_norm[,-which(freq[6,]<400)]
#freq<-freq[,-which(freq[6,]<400)]

pos<-which(colnames(freq) %in% bc_pos)
neg<-which(colnames(freq) %in% bc_neg)

freq_all<-apply(freq_norm,1,mean)
freq_pos<-apply(freq_norm[,pos],1,mean)
freq_neg<-apply(freq_norm[,neg],1,mean)
freq_plot<-round(cbind(freq_all,freq_pos,freq_neg),2)

pv<-round(apply(freq,1,function(a){return(t.test(a[pos],a[neg])$p.value)}),6)

vartypes<-c("A>C or T>G","A>G or T>C","A>T or T>A","C>G or G>C","C>T or G>A","G>T or C>A")


pdf(file="VarTypes_output.pdf",width=6,height=10)
par(xpd=TRUE,mar=c(5,4,4,9))
plcol=c("grey40","green4","grey55","grey70","green3","grey85")
barplot(freq_plot[6:1,],names.arg=c("All","Positive","Negative"),col=plcol)
legend(x=3.85,y=100,legend=vartypes,fill=rev(plcol))
dev.off()

svg(file="VarTypes_output.svg",width=6,height=10)
par(xpd=TRUE,mar=c(5,4,4,9))
plcol=c("grey40","green4","grey55","grey70","green3","grey85")
barplot(freq_plot[6:1,],names.arg=c("All","Positive","Negative"),col=plcol)
legend(x=3.85,y=100,legend=vartypes,fill=rev(plcol))
dev.off()


outtable<-data.frame(vartypes,rep(length(pos),6),rep(length(neg),6),freq_plot,pv)
names(outtable)<-c("VarType","NMutated","NNotMutated","PercVarAll","PercVarMutated","PercVarNotMutated","pValue")
write.table(outtable,file="VarTypes_output.csv",sep="\t",row.names=F,col.names=T,quote=F)
