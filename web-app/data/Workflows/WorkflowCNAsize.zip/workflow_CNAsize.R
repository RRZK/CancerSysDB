barcodes<-read.delim("query1.csv",stringsAsFactors=F)[,1]
cndata_all<-read.delim("query3.csv",stringsAsFactors=F,sep=",",header=F)
cndata_all<-cndata_all[cndata_all[,1] %in% intersect(barcodes,cndata_all[,1]),]
barcodes<-barcodes[barcodes %in% intersect(barcodes,cndata_all[,1])]
bc_pos<-read.delim("query2.csv",stringsAsFactors=F)[,1]
bc_pos<-bc_pos[bc_pos %in% intersect(bc_pos,cndata_all[,1])]
bc_neg<-setdiff(barcodes,bc_pos)


cnregion_neg<-cnregion_pos<-list()
for(bc in bc_neg){
    cndata<-cndata_all[cndata_all[,1]==bc,]
    studies=cndata[cndata[,1]==bc,2]
    study=studies[1]
    cndata[,6]<-2^(cndata[,6]+1)
    cndata_filt<-cndata[cndata[,6]<=1 | 3<=cndata[,6],]
    cnregion_neg[[study]]<-c(cnregion_neg[[study]],sum(as.numeric(cndata_filt[,5]-cndata_filt[,4]))/1000000)
}
for(bc in bc_pos){
    cndata<-cndata_all[cndata_all[,1]==bc,]
    studies=cndata[cndata[,1]==bc,2]
    study=studies[1]
    cndata[,6]<-2^(cndata[,6]+1)
    cndata_filt<-cndata[cndata[,6]<=1 | 3<=cndata[,6],]
    cnregion_pos[[study]]<-c(cnregion_pos[[study]],sum(as.numeric(cndata_filt[,5]-cndata_filt[,4]))/1000000)
}

studies=unique(cndata_all[,2])
cnsize<-matrix(nrow=length(studies),ncol=6)

for(i in 1:length(studies)){
      cnsize[i,1]<-length(cnregion_pos[[studies[i]]])
      cnsize[i,3]<-length(cnregion_neg[[studies[i]]])

      if(cnsize[i,1]>0){cnsize[i,2]<-mean(cnregion_pos[[studies[i]]])}
      if(cnsize[i,3]>0){cnsize[i,4]<-mean(cnregion_neg[[studies[i]]])}
      
      if(cnsize[i,1]>1 && cnsize[i,3]>1){
	 fc<-cnsize[i,2]/cnsize[i,3]
	 if(fc<1){fc= -1/fc}
	 cnsize[i,5]<-fc
         cnsize[i,6]<-t.test(cnregion_pos[[studies[i]]],cnregion_neg[[studies[i]]])$p.value
      }
}

cnregion_pos_all<-as.numeric(unlist(cnregion_pos))
cnregion_neg_all<-as.numeric(unlist(cnregion_neg))


cnsize<-rbind(c(length(cnregion_pos_all),mean(cnregion_pos_all),
		length(cnregion_neg_all),mean(cnregion_neg_all),
		NA,NA),cnsize)
fc<-cnsize[1,2]/cnsize[1,4]
if(fc<1){fc= -1/fc}
cnsize[1,5]<-fc
cnsize[1,6]<-t.test(cnregion_pos_all,cnregion_neg_all)$p.value

rownames(cnsize)<-c("All",studies)
cnsize<-data.frame(rownames(cnsize),cnsize)
colnames(cnsize)<-c("CancerType","NMutated","CNSizeMutated","NNotMutated","CNSizeNotMutated","FoldChange","pValue")
write.table(cnsize,file="CNAsize_output.csv",row.names=F,col.names=T,quote=F,sep="\t")

cnmax=max(c(cnregion_pos_all,cnregion_neg_all))
pdf(file="CNAsize_output.pdf",width=6,height=10)
split.screen(c(2,1))
screen(1)
hist(cnregion_pos_all,breaks=seq(0,1,.025)*cnmax,col="darkred",xlab="Total CNV size [Mb]",ylab="# Patients",main="Mutated",xlim=c(0,cnmax))
screen(2)
hist(cnregion_neg_all,breaks=seq(0,1,.025)*cnmax,col="darkgreen",xlab="Total CNV size [Mb]",ylab="# Patients",main="Not mutated",xlim=c(0,cnmax))
dev.off()


svg(file="CNAsize_output.svg",width=6,height=10)
split.screen(c(2,1))
screen(1)
hist(cnregion_pos_all,breaks=seq(0,1,.025)*cnmax,col="darkred",xlab="Total CNV size [Mb]",ylab="# Patients",main="Mutated",xlim=c(0,cnmax))
screen(2)
hist(cnregion_neg_all,breaks=seq(0,1,.025)*cnmax,col="darkgreen",xlab="Total CNV size [Mb]",ylab="# Patients",main="Not mutated",xlim=c(0,cnmax))
dev.off()

