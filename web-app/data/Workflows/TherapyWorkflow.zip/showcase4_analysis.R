##Read database queries
withmutdata<-as.character(read.table("query1.csv",stringsAsFactors=F,sep=",")[,1])
mutated<-substr(as.character(read.table("query2.csv",sep=",",stringsAsFactors=F)[,1]),1,12)
not_mutated<-substr(setdiff(withmutdata,mutated),1,12)
therapydata<-read.table("query3.csv",sep=",",stringsAsFactors=F,fill=T)
therapydata<-therapydata[grep("//",therapydata[,4]),]
therapydata<-therapydata[-grep("radiation",therapydata[,4]),]
for(i in 2:4){therapydata[,i]<-gsub(" ","",therapydata[,i])}

resplines<-druglines<-numeric(0)
for(i in 1:nrow(therapydata)){
      if(therapydata[i,2]=="measure_of_response"){
	if(therapydata[i,4]==therapydata[i-1,4]){
		resplines<-c(resplines,i)
		druglines<-c(druglines,i-1)
	}
      }
}


therapydata<-cbind(therapydata[druglines,],therapydata[resplines,])[,c(1,3,7)]
names(therapydata)<-c("barcode","drug_name","measure_of_response")

pv<-responders_mut<-responders_not_mut<-nonresponders_mut<-nonresponders_not_mut<-numeric(0)
therapies<-levels(as.factor(therapydata$drug_name))
for(th in therapies){
       responders<-therapydata[therapydata[,2]==th & therapydata[,3]=="CompleteResponse",1]
       nonresponders<-therapydata[therapydata[,2]==th & therapydata[,3]=="ClinicalProgressiveDisease",1]

       responders_mut<-c(responders_mut,length(intersect(responders,mutated)))
       responders_not_mut<-c(responders_not_mut,length(intersect(responders,not_mutated)))
       nonresponders_mut<-c(nonresponders_mut,length(intersect(nonresponders,mutated)))
       nonresponders_not_mut<-c(nonresponders_not_mut,length(intersect(nonresponders,not_mutated)))
       pv<-c(pv,fisher.test(matrix(c(length(intersect(responders,mutated)),length(intersect(responders,not_mutated)),
		length(intersect(nonresponders,mutated)),length(intersect(nonresponders,not_mutated))),nrow=2))$p.value)

}


therapymut<-data.frame(therapies,responders_mut,responders_not_mut,nonresponders_mut,nonresponders_not_mut,pv,stringsAsFactors=F)
therapymut<-therapymut[order(therapymut$pv,decreasing=F),]
names(therapymut)<-c("drug_name","responders_mutated","responders_not_mutated","nonresponders_mutated","nonresponders_not_mutated","p_value")

write.table(therapymut,file="showcase4_output.csv",sep="\t",row.names=F,col.names=T,quote=F)
