metafile <- read.csv('meta.csv')
if(grepl("Stage",metafile['meta'][1,1])){
    metafile['meta'] <- gsub("[A-C]","",as.character(unlist(metafile['meta']))) 
}


valuefile = read.csv('value.csv')
merged <- merge(metafile,valuefile,by="sample")

data <- data.frame()
data2 <- data.frame()
metalist <- unlist(unique(merged['meta']))

for (meta in metalist){
  df <- merged[(merged$meta == meta),c("gene","func","value")]
  agg <- aggregate(.~gene+func, df, FUN = function(x) c(mn = mean(x), n = length(x)))
  df <- as.data.frame(as.list(agg))
  colnames(df) <- c("gene","func","value","samplenum")
  df['sample'] <- meta
  if(nrow(data) == 0){
    data <- df
  }else{
    data <- rbind(data,df)
  }
}
write.csv(data,"data.csv",row.names = FALSE,quote=FALSE)