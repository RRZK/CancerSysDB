#!/usr/bin/env python
import os
import re
import csv
def main():
    dir_path = os.path.dirname(os.path.realpath(__file__))

    outputfile = open("value.csv",'w')
    outputfile.write ("sample,gene,func,value\n")

    linesOne =list()
    linesTwo =list()
    with open("value1.csv") as f:
        reader1 = csv.reader(f)
        for row in reader1:
            linesOne.append(row)
    with open("value2.csv") as f:
        reader2 = csv.reader(f)
        for row in reader2:
            linesTwo.append(row)
    
    for line in linesOne:
	#Optimizeable
        for line2 in linesTwo:
            if(line2[0]==line[1]):
                outputfile.write (','.join( [ line[0] , line[1], line2[1],  line[2]]) + "\n")

main()
