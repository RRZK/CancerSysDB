#!/usr/bin/env python

import os, re
import pandas as pd
dir_path = os.path.dirname(os.path.realpath(__file__))

metafile = pd.read_csv('meta.csv')
metafile.drop('name',axis=1,inplace=True)
if ("Stage" in metafile['meta'][0]):
    metafile['meta'] = metafile['meta'].str.replace(r'[A-C]', '')

valuefile = pd.read_csv('value.csv')
merged = pd.merge(metafile, valuefile, how='inner', on=['sample'])

data = pd.DataFrame()
metalist = merged.meta.unique()

for meta in metalist:
    df = merged[merged['meta']==meta]
    df = df.groupby(['gene','func']).agg({'sample':'size', 'value':'mean'}).rename(columns={'sample':'samplenum'}).reset_index()
    df['sample'] = meta
    if data.empty:
        data = df
    else:
        data = data.append(df)

data.to_csv("data.csv",columns=['sample','gene','func','value','samplenum'],index=False)
