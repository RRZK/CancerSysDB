#!/usr/bin/env python
import os
import re
import csv
def main():
    dir_path = os.path.dirname(os.path.realpath(__file__))

    outputfile = open("data.csv",'w')
    outputfile.write ("sample,gene,func,value,mutation\n")

    lines = []

    #CombineMutationFiles

    names = set()

    for file in os.listdir(dir_path):
        if file.endswith(".csv") and file.startswith("PartOne"):
            names.add(file[len("PartOne"): len(file)-len(".csv")])

    for name in names:
        CombineCSV(name)

    #All Lines into List

    for file in os.listdir(dir_path):
        if file.endswith(".csv") and file.startswith("patient"):
            with open(file) as f:
                for line in f:
                    if line.strip() != "":
                    	lines.append(line)
    #Sort Lines

    #print len(lines) 
    lines.sort()

    #for line in lines:
    #    print line

    lastNonMutantLine =""
    accMutations = []
    counter =0
    for line in lines:
        #Mutation must be Accumulatedin Original Workflow this was Supplied by Mysql In general SQL this isnt Availibe so its done here
        m = re.search(r"^(.*),([^,]*)$", line)
        #print m.group(1)
        mutt = m.group(2).strip()

        if m.group(1) != lastNonMutantLine:
            if lastNonMutantLine != "":
                #Write Last Mutation
                if len(accMutations) > 0:
                    accMutationsString = "|".join(accMutations)
                else:
                    #If There are no Mutation write Null
                    accMutationsString = "NULL"
                #WriteLine To 
                outputfile.write(lastNonMutantLine +","+ accMutationsString+"\n")
                counter +=1
                accMutations = []

            lastNonMutantLine = m.group(1)

        if mutt !='NULL':
            accMutations.append( mutt)


    #Write Final Line
    if len(accMutations) >0:
        accMutationsString = "|".join(accMutations)
    else:
        #If There are no Mutation write Null
        accMutationsString = "NULL"
        #WriteLine To 
    if lastNonMutantLine != "":
        outputfile.write(lastNonMutantLine +","+ accMutationsString+"\n")
        counter +=1

    #print "lines" +str(counter)
    #Close File
    outputfile.close()


def CombineCSV(ending):
    linesOne =list()
    linesTwo =list()
    with open("PartOne" +ending+".csv") as f:
        reader1 = csv.reader(f)
        for row in reader1:
            linesOne.append(row)
    with open("PartTwo" +ending+".csv") as f:
        reader2 = csv.reader(f)
        for row in reader2:
            linesTwo.append(row)
    
    nameOut= "patient"+ending+".csv"

    outputfile = open(nameOut,'w')
    for line in linesOne:
        for line2 in linesTwo:
            if(line2[0]==line[0] and line2[1]==line[1]):
                outputfile.write (','.join( [ line[0] , line[1], line[2],  line2[2],line[3]]) + "\n")
main()