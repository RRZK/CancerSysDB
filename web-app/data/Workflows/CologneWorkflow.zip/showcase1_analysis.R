abundance<-read.table("query1.csv",stringsAsFactors=F,sep=",")
withmutdata<-read.table("query2.csv",stringsAsFactors=F,sep=",")
mutated<-read.table("query3.csv",sep=",",stringsAsFactors=F)
not_mutated=withmutdata[!(withmutdata[,1] %in% mutated[,1]),]

abundance_mutated=abundance[abundance[,2] %in% substr(mutated[,1],1,12),]
abundance_not_mutated=abundance[!(abundance[,2] %in% substr(mutated[,1],1,12)),]

abundance_mutated<-abundance_mutated[abundance_mutated[,5]>0,]
abundance_not_mutated<-abundance_not_mutated[abundance_not_mutated[,5]>0,]


studyids<-c("All",unique(abundance[,3]))
n_mut<-nrow(abundance_mutated)
n_notmut<-nrow(abundance_not_mutated)
n_total<-n_mut+n_notmut
abundance_plot<-list()
abundance_plot[[1]]<-abundance_mutated[,5]
abundance_plot[[2]]<-abundance_not_mutated[,5]
mean_mut<-mean(abundance_mutated[,5])
mean_notmut<-mean(abundance_not_mutated[,5])
ratio<-mean_mut/mean_notmut
pvalue<-t.test(abundance_mutated[,5],abundance_not_mutated[,5])$p.value
apl=2

legendstudies="All"
for(studyid in studyids[-1]){
	    am_thisstudy<-abundance_mutated[abundance_mutated[,3]==studyid,]
	    anm_thisstudy<-abundance_not_mutated[abundance_not_mutated[,3]==studyid,]
    	    n_mut<-c(n_mut,nrow(am_thisstudy))
    	    n_notmut<-c(n_notmut,nrow(anm_thisstudy))
	    n_total<-c(n_total,nrow(am_thisstudy)+nrow(anm_thisstudy))
	    if(nrow(am_thisstudy)>0 && nrow(anm_thisstudy)>0){
	        apl=apl+1
	    	abundance_plot[[apl]]<-am_thisstudy[,5]
	    	apl=apl+1
	    	abundance_plot[[apl]]<-anm_thisstudy[,5]
		legendstudies<-c(legendstudies,studyid)
	    }
	    mean_mut<-c(mean_mut,mean(am_thisstudy[,5]))
	    mean_notmut<-c(mean_notmut,mean(anm_thisstudy[,5]))
	    if(min(c(nrow(am_thisstudy),nrow(anm_thisstudy)))>1){
	    	ratio<-c(ratio,mean(am_thisstudy[,5])/mean(anm_thisstudy[,5]))
	    	pvalue<-c(pvalue,t.test(am_thisstudy[,5],anm_thisstudy[,5])$p.value)
	    } else{
	      ratio<-c(ratio,NA)
	      pvalue<-c(pvalue,NA)
	    }
}

result<-data.frame(studyids,n_total,n_mut,round(mean_mut,2),n_notmut,round(mean_notmut,2),round(ratio,2),round(pvalue,6),stringsAsFactors=F)
names(result)<-c("STUDY_ID","N","#MUTATED","MEAN_MUTATED","#NON-MUTATED","MEAN_NON-MUTATED","RATIO","P_VALUE")
write.table(result,file="showcase1_output.csv",sep="\t",row.names=F,col.names=T,quote=F)


plotat=seq(1,length(abundance_plot)*3/2,1)
plotat=plotat[plotat %% 3 != 0]
ncohorts=length(abundance_plot)/2
library(RColorBrewer)
colpalette=c(brewer.pal(12,"Set3"),brewer.pal(9,"Set1"))
bpcolors=rep("grey",ncohorts*2)
bpcolors[seq(1,2*ncohorts,2)]=colpalette[1:ncohorts]
bpcolors[seq(2,2*ncohorts,2)]=colpalette[1:ncohorts]

for(f in 1:2){
      if(f==1){svg("showcase1_output.svg",height=7,width=length(abundance_plot)/2)}
      if(f==2){pdf("showcase1_output.pdf",height=7,width=length(abundance_plot)/2)}
      par(mar=c(5,4,4,14),oma=c(0,0,0,0),xpd=T)
      boxplot(abundance_plot,at=plotat,
	range=0,names=rep(c("w/ mut","w/o mut"),length(abundance_plot)/2),cex.axis=.8,las=2,
	col=bpcolors,main="Gene expression [T/N]",ylab="log2(FoldChange)")
	legend(max(plotat)+3,max(unlist(abundance_plot)),legend=legendstudies,fill=bpcolors[seq(1,2*ncohorts,2)],cex=.7)
	dev.off()
}
