library(survival)

##Read database queries
withmutdata<-read.table("query1.csv",stringsAsFactors=F,sep=",")
mutated<-read.table("query2.csv",sep=",",stringsAsFactors=F)
survdata<-read.table("query3.csv",sep=",",stringsAsFactors=F)
survdata<-survdata[survdata[,3]>0,]
survdata[,2]<-gsub("days_to_death","DEAD",survdata[,2])
survdata[,2]<-gsub("days_to_last_followup","CENSORED",survdata[,2])
survdata<-survdata[order(survdata[,1],survdata[,3],decreasing=T),]
survdata<-survdata[!duplicated(survdata[,1]),]
survdata<-survdata[order(survdata[,1]),]

##Rearrange data
withmutdata[,1]<-substr(withmutdata[,1],1,12)
mutated[,1]<-substr(mutated[,1],1,12)
indata<-data.frame(withmutdata,mutated[match(withmutdata[,1],mutated[,1]),],survdata[match(withmutdata[,1],survdata[,1]),],stringsAsFactors=F)
indata<-indata[!is.na(indata[,5]),-3]
indata[,2]<-ifelse(is.na(indata[,2]),0,1)
names(indata)<-c("Barcode","MutationStatus","EventStatus","TimeToEvent")

##Fit Kaplan-Meier curves and test hypothesis
sfit<-survfit(Surv(indata$TimeToEvent,(indata$EventStatus=="DEAD"))~indata[,2])
sdiff<-survdiff(Surv(indata$TimeToEvent,(indata$EventStatus=="DEAD"))~indata[,2])
meddiff=abs(summary(sfit)$table[1,5]-summary(sfit)$table[2,5])
pv<-round(1-pchisq(sdiff$chisq,length(sdiff$n)-1),4)

##Plot curve
pdf("showcase3_output.pdf")
plot(sfit,main=paste("Survival by mutation status (n=",sum(!is.na(indata$TimeToEvent)),")",sep=""),col=c("black","red"),xlab="Overall survival [d]",ylab="Patients alive [%]",yscale=100)
legend(5300,1,legend=c("Mutated","Not mutated"),fill=c("red","black"))
dev.off()

##Summarize results
result<-cbind(c("Mutated","Not mutated"),summary(sfit)$table[c(2,1),3:7])
colnames(result)<-c("Mutation status","Patients","Events","Median","0.95LCL","0.95UCL")
write.table(result,file="showcase3_output.txt",sep="\t",row.names=F,col.names=T,quote=F)
cat("\nMedian Survival Gain: ",meddiff,"\n",file="showcase3_output.txt",append=T)
cat("Logrank test: ",pv,"\n",file="showcase3_output.txt",append=T)
