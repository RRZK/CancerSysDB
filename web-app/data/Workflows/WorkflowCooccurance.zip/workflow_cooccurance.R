bc_pos<-read.delim("query1.csv",stringsAsFactors=F)[,1]
mutations<-read.delim("query2.csv",stringsAsFactors=F,sep=",",header=F)
mutations[,1]<-gsub("[","",mutations[,1],fixed=T)
mutations[,1]<-gsub(" ","",mutations[,1],fixed=T)
mutations[,7]<-gsub("]","",mutations[,7],fixed=T)
mutations[,7]<-gsub(" ","",mutations[,7],fixed=T)
barcodes<-unique(mutations[,1])
bc_neg<-setdiff(barcodes,bc_pos)

genes<-unique(mutations[,7])
patients<-unique(mutations[,1])

mutations_pos<-mutations[mutations[,1] %in% bc_pos,]
mutations_neg<-mutations[mutations[,1] %in% bc_neg,]

both<-onlyg<-onlysplit<-none<-pv<-numeric(0)
for(i in 1:length(genes)){
      pat_mut<-unique(mutations[mutations[,7]==genes[i],1])
      pat_notmut<-setdiff(patients,pat_mut)
      both[i]<-length(intersect(pat_mut,mutations_pos[,1]))
      onlyg[i]<-length(intersect(pat_mut,mutations_neg[,1]))
      onlysplit[i]<-length(intersect(pat_notmut,mutations_pos[,1]))
      none[i]<-length(intersect(pat_notmut,mutations_neg[,1]))
      M<-matrix(c(both[i],onlyg[i],onlysplit[i],none[i]),nrow=2)
      pv[i]<-fisher.test(M)$p.value
}

result<-data.frame(genes,both,onlyg,onlysplit,none,pv)
names(result)<-c("Gene","BothMutated","OnlyThisMutated","OnlySplitMutated","NoneMutated","pValue")
result_sorted<-result[order(result$pValue,decreasing=F),]
result_sorted<-result_sorted[-1,]

write.table(result_sorted,file="workflow_cooccurance.csv",sep="\t",row.names=F,col.names=T,quote=F)
