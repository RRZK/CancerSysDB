metafile <- read.csv('meta.csv')

df <- metafile[!duplicated(metafile[c("sample","metaname")]),]

stage <- df[(df$metaname=="pathologic_stage"),c("sample","meta")]
colnames(stage) <- c("sample","stage")

gender <- df[(df$metaname=="gender"),c("sample","meta")]
colnames(gender) <- c("sample","gender")

vital <- df[(df$metaname=="vital_status"),c("sample","meta")]
colnames(vital) <- c("sample","vital")

cohort <- as.character(df['cohort'][1,1])

if(grepl("Stage",stage['stage'][1,1])){
  stage['stage'] <- gsub("[A-C]","",as.character(unlist(stage['stage']))) 
}

valuefile = read.csv('value.csv')
valuefile <- valuefile[!duplicated(valuefile[c("sample","gene","process")]),]
merged <- merge(valuefile,stage,by="sample",all.x=TRUE)
merged <- merge(merged,gender,by="sample",all.x=TRUE)
merged <- merge(merged,vital,by="sample",all.x=TRUE)

merged$stage[is.na(merged$stage)] <- 'Stage NA'
merged[is.na(merged)] <- 'NA'
merged['cohort'] <- cohort

write.csv(merged,"data.csv",row.names = FALSE,quote=FALSE)